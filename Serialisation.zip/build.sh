#!/bin/bash

g++ main.cpp Cell.cpp Path.cpp vibes.cpp -o maze